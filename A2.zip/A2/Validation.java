
/**
 * Validation of input by users. In order to valid users' input and avoid useless input.
 * 
 * @author (YIPENG LI) 
 * @version (09/10/2017)
 */
public class Validation
{
    private int index;
    /**
     * Defalut Constructor of class Validation. Initialize value of index.
     */
    public Validation()
    {
        // initialise instance variables
        index = 0;
    }
    
    /**
     * checkStr() method in order to valid users' input as characters A-Z, and no emputy or 
     * space input.
     * @ param chara. input by users.
     * @ return a boolean value.
     */
    public boolean checkStr(String chara)
    {
        if (chara.trim().length() == 0)
            return false;
        while (index < chara.length())
        {
            char newChara = chara.toUpperCase().charAt(index);
            if (newChara < 'A' || newChara > 'Z')
                return false;
            index++;
        }
        return true;
    }
    
    /**
     * checkNum() method in order to valid users' input as numbers from 0-9, and no emputy or 
     * space input.
     * @ param num. input by users.
     * @ return a boolean value.
     */
    public boolean checkNum(String num)
    {
        if (num.trim().length() == 0)
            return false;
        while (index < num.length())
        {
            char newNum = num.charAt(index);
            if (newNum < '0' || newNum > '9')
                return false;
            index++;
        }
        return true;
    }
    
    /**
     * checkSpaceStr() method in order to valid users' input as characters A-Z, and emputy  
     *  inputs are acceptable.
     * @ param chara. input by users.
     * @ return a boolean value.
     */
    public boolean checkSpaceStr(String chara)
    {
        if (chara != null)
        {
            while (index < chara.length())
            {
                char newChara = chara.toUpperCase().charAt(index);
                if (newChara < 'A' && newChara > 'Z')
                    return false;
                index++;
            }
       }
       else
           return true;
       return true;
    }
}
