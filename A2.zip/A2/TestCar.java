import java.util.ArrayList;
/**
 * Write a description of class Car here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestCar
{
    // instance variables
    private String carReg;
    private int yearMade;
    private String color1;
    private String color2;
    private String color3;
    private String carMake;
    private String carModel;
    private int price;
    /**
     * Constructor for objects of class Car
     */
    public TestCar()
    {
        // initialise instance variables
        carReg = "000000";
        yearMade = 0;
        color1 = "color";
        color2 = "color";
        color3 = "color";
        carMake = "make";
        carModel = "model";
        price = 0;
    }
    
    public TestCar(String newCarReg,
                   int newYear,
                   String newColor1,
                   String newColor2,
                   String newColor3,
                   String newCarMake,
                   String newCarModel,
                   int newPrice)
    {
        // initialise instance variables
        carReg = newCarReg;
        yearMade = newYear;
        color1 = newColor1;
        color2 = newColor2;
        color3 = newColor3;
        carMake = newCarMake;
        carModel = newCarModel;
        price = newPrice;
        if (carReg.trim().length() > 6 || carReg.trim().length() == 0)
            carReg = "000000";
        if (yearMade > 2017 || yearMade < 0)
            yearMade = 0;
        if (color1.trim().length() == 0 &&
            color2.trim().length() == 0 &&
            color3.trim().length() == 0)
        {
            color1 = "color"; 
            color2 = "color"; 
            color3 = "color";
        }
        if (carMake.trim().length() <= 0)  
            carMake = "make";
        if (carModel.trim().length() <= 0)
            carModel = "mode";
        if (price <= 0)
            price = 0;
            
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public String getCarReg()
    {
        return carReg;
    }
    
    public void setCarReg(String carReg)
    {
        if (carReg.trim().length() <= 6 && carReg.trim().length() > 0)
            this.carReg = carReg;
    }
    
    public int getYearMade()
    {
        return yearMade;
    }
    
    public void setYearMade(int yearMade)
    {
        if (yearMade < 2018 && yearMade > 0)
            this.yearMade = yearMade;
    }
    
    public String getColor1()
    {
        return color1;
    }
    
    public void setColor1(String color1)
    {
        if (color1.trim().length() > 0)
            this.color1 = color1;
    }
    
    public String getColor2()
    {
        return color2;
    }
    
    public void setColor2(String color2)
    {
        if (color2.trim().length() > 0)
            this.color2 = color2;
    }
    
    public String getColor3()
    {
        return color3;
    }
    
    public void setColor3(String color3)
    {
        if (color3.trim().length() > 0)
            this.color3 = color3;
    }
    
    public String getCarMake()
    {
        return carMake;
    }
    
    public void setCarMake(String carMake)
    {
        if (carMake.trim().length() > 0)
            this.carMake = carMake;
    }
    
    public String getCarModel()
    {
        return carModel;
    }
    
    public void setCarModel(String carModel)
    {
        if (carModel.trim().length() > 0)
            this.carModel = carModel;
    }
    
    public int getPrice()
    {
        return price;
    }
    
    public void setPrice(int price)
    {
        if (price > 0)
            this.price = price;
    }
    
    public String carToString()
    {
        return  carReg + "," + yearMade + "," + color1 + "," + color2
               + "," + color3 + "," + carMake + "," + carModel + "," + price;
    }
    
    public void display()
    {
        System.out.println(carReg);
        System.out.println(yearMade);
        System.out.println(color1);
        System.out.println(color2);
        System.out.println(color3);
        System.out.println(carMake);
        System.out.println(carModel);
        System.out.println(price);
    }
}
