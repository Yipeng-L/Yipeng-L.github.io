import java.util.*;
/**
 * A collection of cars. With some basic functions like adding, removing, searching.
 * A set of car objects. Do some operation to car objects.
 * @author (YIPENG LI) 
 * @version (09/10/2017)
 */
public class CarCollection
{
    private ArrayList<Car> car;

    /**
     * Defalut constructor of class CarCollection.
     */
    public CarCollection()
    {
        // initialise instance variables
        car = new ArrayList<Car>();
    }

    /**
     * AddCar() method - adding car objects.
     * 
     * @param  cars   car objects.
     * @return    no return value.
     */
    public void addCar(Car cars)
    {
        car.add(cars);
    }
    
    /**
     * removeCar() method - deleting car objects.
     * 
     * @param  cars   car objects.
     * @return    no return value.
     */
    public void removeCar(Car cars)
    {
        car.remove(cars);
    }
    
    /**
     * countCar() method - get numbers of car objects.
     * 
     * @param  null.
     * @return    car.size()   number of cars.
     */
    public int countCar()
    {
        return car.size();
    }
    
    /**
     * getCar(index) method - get car information by index of cars in the array list.
     * 
     * @param  index.
     * @return    car  car information by searching the index.
     */
    public Car getCar(int index)
    {
        return car.get(index);
    }
    
    /**
     * getAllCars() method - get all cars' information.
     * 
     * @param  null.
     * @return    car    car objects.
     */
    public List<Car> getAllCars()
    {
        return car;
    }
    
    /**
     * listCars() method - list car information as a list.
     * 
     * @param  null.
     * @return    no return value.
     */
    public void listCars()
    {
        for (int i = 0; i < car.size(); i++)
        {
            System.out.println(i + 1 + "." + car.get(i).getCarReg() + car.get(i).getYearMade() 
                 + car.get(i).getColor1() + car.get(i).getColor2() + car.get(i).getColor3() 
                 + car.get(i).getCarMake() + car.get(i).getCarModel() + car.get(i).getPrice());
        }
    }
}
