import java.util.ArrayList;
/**
 * This Car class aims to store the information of a car, and declare the elements of used cars.
 * 
 * @author (YIPENG LI) 
 * @version (09/10/2017)
 */
public class Car
{
    // instance variables
    private String carReg;
    private int yearMade;
    private String color1;
    private String color2;
    private String color3;
    private String carMake;
    private String carModel;
    private int price;
    /**
     * Default Constructor of class Car. Aims to initialize fields.
     */
    public Car()
    {
        // initialise instance variables
        carReg = "";
        yearMade = 0;
        color1 = "";
        color2 = "";
        color3 = "";
        carMake = "";
        carModel = "";
        price = 0;
    }
    
    /**
     * Non-default Constructor of class Car.
     * 
     * @ param newCarReg, newYear, newColor1, newColor2, newColor3,newCarMake,newCarModel,newPrice
     * no return value.
     */
    public Car(String newCarReg,
               int newYear,
               String newColor1,
               String newColor2,
               String newColor3,
               String newCarMake,
               String newCarModel,
               int newPrice)
    {
        carReg = newCarReg;
        yearMade = newYear;
        color1 = newColor1;
        color2 = newColor2;
        color3 = newColor3;
        carMake = newCarMake;
        carModel = newCarModel;
        price = newPrice;
    }

    /**
     * getCarReg() method, using for get registration number of cars.
     * 
     * @param  no param
     * @return   carReg: car registration number
     */
    public String getCarReg()
    {
        return carReg;
    }
    
    /**
     * setCarReg() method, assign values to carReg.
     * 
     * @param  carReg.
     * @return   no return value.
     */
    public void setCarReg(String carReg)
    {
        this.carReg = carReg;
    }
    
    /**
     * getYearMade() method, using for get year made of cars.
     * 
     * @param  no param.
     * @return   yearMade: made year of a car.
     */
    public int getYearMade()
    {
        return yearMade;
    }
    
    /**
     * setYearMade() method, assign values to yearMade.
     * 
     * @param  yearMade
     * @return   no return value.
     */
    public void setYearMade(int yearMade)
    {
         this.yearMade = yearMade;
    }
    
    /**
     * getColor1() method, using for get color information of cars.
     * 
     * @param  no param.
     * @return   color1: one color of a car.
     */
    public String getColor1()
    {
        return color1;
    }
    
    /**
     * setColor1() method, assign values to color1.
     * 
     * @param  color2
     * @return   no return value.
     */
    public void setColor1(String color1)
    {
        this.color1 = color1;
    }
    
    /**
     * getColor2() method, using for get color information of cars.
     * 
     * @param  no param.
     * @return   color2: one color of a car.
     */
    public String getColor2()
    {
        return color2;
    }
    
    /**
     * setColor2() method, assign values to color2.
     * 
     * @param  color2
     * @return   no return value.
     */
    public void setColor2(String color2)
    {
         this.color2 = color2;
    }
    
    /**
     * getColor3() method, using for get color information of cars.
     * 
     * @param  no param.
     * @return   color3: one color of a car.
     */
    public String getColor3()
    {
        return color3;
    }
    
    /**
     * setColor3() method, assign values to color3.
     * 
     * @param  color3
     * @return   no return value.
     */
    public void setColor3(String color3)
    {
        this.color3 = color3;
    }
    
    /**
     * getCarMake() method, get car make information.
     * 
     * @param  null
     * @return   carMake.
     */
    public String getCarMake()
    {
        return carMake;
    }
    
    /**
     * setCarMake() method, assign car make information.
     * 
     * @param  carMake
     * @return   no return value.
     */
    public void setCarMake(String carMake)
    {
         this.carMake = carMake;
    }
    
    /**
     * getCarModel() method, get car model information.
     * 
     * @param  null
     * @return   carModel.
     */
    public String getCarModel()
    {
        return carModel;
    }
    
    /**
     * setCarModel() method, assign car model information.
     * 
     * @param  carModel
     * @return   no return value.
     */
    public void setCarModel(String carModel)
    {
        this.carModel = carModel;
    }
    
    /**
     * getPrice() method, assign car price information.
     * 
     * @param  no.
     * @return   price.
     */
    public int getPrice()
    {
        return price;
    }
    
    /**
     * setPrice() method, assign car price information.
     * 
     * @param  price
     * @return   no return value.
     */
    public void setPrice(int price)
    {
        this.price = price;
    }
    
    /**
     * carToString() method, return car information as a Stting.
     * 
     * @param  null.
     * @return   carReg,yearMade,color1,color2,color3,carMake,carModel,price.
     */
    public String carToString()
    {
        return  carReg + "," + yearMade + "," + color1 + "," + color2
               + "," + color3 + "," + carMake + "," + carModel + "," + price;
    }
}
