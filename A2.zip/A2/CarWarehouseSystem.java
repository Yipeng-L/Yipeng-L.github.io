import java.util.*;
import java.io.*;
import java.text.*;
/**
 * CarWarehouseSystem class, to do adding, searching, editing, deleting functions to cars inforamtion.
 * With this system, users can searching car information, owners can update car information. 
 * There are also some functions helps users to do operation to used cars in the database.
 * @author (YIPENG LI) 
 * @version (19/10/2017)
 */
public class CarWarehouseSystem
{
    private CarCollection carCollection;
    /**
     *  Defalut constructor of class CarWarehouseSystem.
     *  create objects of cars' collection.
     *  @param null
     *  @return no return value.
     */
    public CarWarehouseSystem()
    {
        // initialise instance variables
        carCollection = new CarCollection();
    }
    
    /**
     * displayMenu() method - display a main menu of used car warehouse system.
     * 
     * @param  null.
     * @return   null. 
     */
    private void displayMenu()
    {
        System.out.println("Used Car Warehouse Database System");
        System.out.println("===================================");
        System.out.println("(1) Search Cars");
        System.out.println("(2) Add Car");
        System.out.println("(3) Delete Car");
        System.out.println("(4) Edit Car");
        System.out.println("(5) Display Date");
        System.out.println("(6) Exit System");
    }
    
    /**
     * readCarInfo() method - read car information of a .txt file.
     * 
     * @param  null.
     * @return   null. 
     */
    private void readCarInfo()
    {
        try
        {
            String fileName = "usedcars.txt";
            Car car = null;
            FileReader file = new FileReader(fileName);
            Scanner carInfo = new Scanner(file);
            while (carInfo.hasNextLine())
            {
                String elements = carInfo.nextLine();
                System.out.println(elements);
                String [] Data = elements.split(",");
                car = new Car(Data[0],Integer.parseInt(Data[1]),Data[2],Data[3],Data[4],Data[5],Data[6],Integer.parseInt(Data[7]));
                carCollection.addCar(car);
            }
            file.close();
        }
        catch(IOException ex)
        {
            System.out.println("Loading Error!");
        }
    }
    
    /**
     * checkReg() method - valid registration number that entered by users.
     * 
     * @param  null.
     * @return   reg    registration number typed by users. 
     */
    private String checkReg()
    {
        System.out.println("Please type in car Registration Number:");
        Validation isValidation = new Validation();
        Scanner input = new Scanner(System.in);
        String reg = input.nextLine().toUpperCase();
        boolean flag = true;
        while (flag)
        {
            if ((isValidation.checkStr(reg) || isValidation.checkNum(reg)) && reg.length() <= 6)
            {
                for (int i = 0; i < carCollection.countCar(); i++)
                {
                    if(carCollection.getCar(i).getCarReg().equals(reg))
                    {
                        System.out.println("This car registration number already exists,");
                        System.out.println("and it can not be added again.");
                        System.out.println("Please type again: ");
                        reg = input.nextLine();
                        flag = true;
                    }
                    else
                        flag = false;
                }
            }
            else
            {
                System.out.println("Invalid input and try again: ");
                reg = input.nextLine().toUpperCase();
                flag = true;
            }
        }
        return reg;
    }
    
    /**
     * checkYear() method - valid year made of cars that entered by users.
     * 
     * @param  null.
     * @return   carYear    year made of cars. 
     */
    private String checkYear()
    {
        System.out.println("Please type in car Made Year:");
        Validation isValidation = new Validation();
        Scanner input = new Scanner(System.in);
        String carYear = input.nextLine();
        int year = Calendar.getInstance().get(Calendar.YEAR);
        boolean yFlag = true;
        while (yFlag)
        {
            if (isValidation.checkNum(carYear) && 
                carYear.length() <= 4 && 
                Integer.parseInt(carYear) <= year && 
                Integer.parseInt(carYear) > 0)
                yFlag = false;
            else
            {
                System.out.println("Invalid input and try again: ");
                carYear = input.nextLine();
                yFlag = true;
            }
        }
        return carYear;
    }
    
    /**
     * checkMake() method - valid car make that entered by users.
     * 
     * @param  null.
     * @return   carMa    car make of cars. 
     */
    private String checkMake()
    {
        System.out.println("Please type in car Make:");
        Validation isValidation = new Validation();
        Scanner input = new Scanner(System.in);
        String carMa = input.nextLine();
        boolean mFlag = true;
        while (mFlag)
        {
            if (isValidation.checkStr(carMa))
                mFlag = false;
            else
            {
                System.out.println("Invalid input and try again: ");
                carMa = input.nextLine();
                mFlag = true;
            }
        }
        return carMa;
    }
    
    /**
     * checkModel() method - valid car model that entered by users.
     * 
     * @param  null.
     * @return   carMo    car model of cars. 
     */
    private String checkModel()
    {
        System.out.println("Please type in car Model:");
        Validation isValidation = new Validation();
        Scanner input = new Scanner(System.in);
        String carMo = input.nextLine();
        boolean moFlag = true;
        while (moFlag)
        {
            if (isValidation.checkStr(carMo) || isValidation.checkNum(carMo))
                moFlag = false;
            else
            {
                System.out.println("Invalid input and try again: ");
                carMo = input.nextLine();
                moFlag = true;
            }
        }
        return carMo;
    }
    
    /**
     * checkPrice() method - valid car price that entered by users.
     * Input should be numbers.
     * @param  null.
     * @return   carPr    prices of cars. 
     */
    private String checkPrice()
    {
        System.out.println("Please type in car Price:");
        Validation isValidation = new Validation();
        Scanner input = new Scanner(System.in);
        String carPr = input.nextLine();
        boolean pFlag = true;
        while (pFlag)
        {
            if (isValidation.checkNum(carPr))
            {
                if(Integer.parseInt(carPr) > 0)
                {
                    pFlag = false;
                }
                else
                {
                    System.out.println("Price can not be negative number: ");
                    carPr = input.nextLine();
                    pFlag = true;
                }
            }
            else
            {
                System.out.println("Invalid input and try again: ");
                carPr = input.nextLine();
                pFlag = true;
            }
        }
        return carPr;
    }
    
    /**
     * addCar() method - Add car information to the car collection.
     * 
     * @param  null.
     * @return   null. 
     */
    private void addCar()
    {
        String carReg = checkReg();;
        String year = checkYear();
        System.out.println("Please type in car colors:");
        Validation isValidation = new Validation();
        Scanner input = new Scanner(System.in);
        String carCol1 = input.nextLine();
        String carCol2 = input.nextLine();
        String carCol3 = input.nextLine(); 
        boolean flag1 = true;
        while (flag1)
        {
            if (isValidation.checkSpaceStr(carCol1) && 
                isValidation.checkSpaceStr(carCol2) && 
                isValidation.checkSpaceStr(carCol3))
            {
                if (carCol1.length() != 0 || carCol2.length() != 0 || carCol3.length() != 0)
                {
                    flag1 = false;
                }
                else
                {
                    System.out.println("At least one color needed and try again: ");
                    carCol1 = input.nextLine();
                    carCol2 = input.nextLine();
                    carCol3 = input.nextLine();
                }
            }       
            else
            {
                System.out.println("Invalid input and try again: ");
                carCol1 = input.nextLine();
                carCol2 = input.nextLine();
                carCol3 = input.nextLine();
                flag1 = true;
            }
        }
        String make = checkMake();
        String model = checkModel();
        String price = checkPrice();
        String carInfo = carReg + "," + year + "," + carCol1 + "," + carCol2 + "," + carCol3 + "," + 
                         (make.substring(0,1).toUpperCase() + make.substring(1)) + "," + 
                         (model.substring(0,1).toUpperCase() + model.substring(1)) + "," + price;
        String[] data = carInfo.split(",");
        Car car = new Car(data[0],Integer.parseInt(data[1]),data[2],data[3],data[4],data[5],data[6],Integer.parseInt(data[7]));
        carCollection.addCar(car);
    }
    
    /**
     * deleteCar() method - delete car information from the car collection.
     * 
     * @param  null.
     * @return   null. 
     */
    private void deleteCar()
    {
        System.out.println("Please input car regustration numbers to delete car information: ");
        try
        {
            Validation isValidation = new Validation();
            Scanner info = new Scanner(System.in);
            String input = info.nextLine();
            boolean flag = true;
            while (flag)
            {
                if ((isValidation.checkStr(input) || isValidation.checkNum(input)) && input.length() <= 6)
                {
                    boolean found = false;
                    for (int i = 0; i < carCollection.countCar(); i++)
                    {
                        if (carCollection.getCar(i).getCarReg().equals(input))
                        {
                            carCollection.removeCar(carCollection.getCar(i));
                            found = true;
                            break;
                        }
                    }
                    if (found)
                    {
                        System.out.println("Remove successfully.");
                        flag = false;
                    }
                    else
                    {
                        System.out.println("Car not found.");
                        System.out.println("Please try another car: ");
                        input = info.nextLine();
                        flag = true;
                    }
                }
                else
                {
                    System.out.println("Invalid input, try again: ");
                    input = info.nextLine();
                    flag = true;
                }
            }
            info.close();
        }
        catch (Exception e)
        {
            System.out.println("Error, try again.");
        }
    }
    
    /**
     * displayCurrentCars() method - display all current cars that are stored in the collection.
     * 
     * @param  null.
     * @return   null. 
     */
    private void displayCurrentCars()
    {
        for (int i = 0; i < carCollection.countCar(); i++)
        {
              System.out.println(i +  "." + carCollection.getCar(i).carToString());
        }
    }
    
    /**
     * checkIndex() method - make sure users using valid index numbers.
     * 
     * @param  null.
     * @return   input   index that a user entered.
     */
    private String checkIndex()
    {
        Validation isValidation = new Validation();
        System.out.println("");
        System.out.println("Please choose a car by index number to Edit:");
        Scanner search = new Scanner(System.in);
        String input = search.nextLine();
        boolean flag = true;
        while (flag)
        {
            if (!isValidation.checkNum(input) || 
                Integer.parseInt(input) > carCollection.countCar() - 1 || 
                Integer.parseInt(input) < 0)
            {
               System.out.println("Invalid index number and try again:");
               input = search.nextLine();
               flag = true;
            }
            else
                flag = false;
        }
        return input;
    }
    
    /**
     * editColors() method - edit car colors.
     * 
     * @param  index.
     * @return   null.
     */
    private void editColors(String index)
    {
        Validation isValidation = new Validation();
        System.out.println("Please edit car colors:");
        Scanner searchCar = new Scanner(System.in);
        String carCol1 = searchCar.nextLine();
        String carCol2 = searchCar.nextLine();
        String carCol3 = searchCar.nextLine();
        boolean newFlag = true;
        while (newFlag)
        {
            if (isValidation.checkSpaceStr(carCol1) && 
                isValidation.checkSpaceStr(carCol2) && 
                isValidation.checkSpaceStr(carCol3))
            {
                if (carCol1.length() != 0 || carCol2.length() != 0 || carCol3.length() != 0)
                {
                    int indexNum = Integer.parseInt(index);
                    for (int i = 0; i < carCollection.countCar(); i++)
                    {
                        if (i == indexNum)
                        {
                            if(carCol1.equals(""))
                                carCollection.getCar(indexNum).setColor1("");
                            else
                            {
                                String newCol1 = carCol1.substring(0,1).toUpperCase() + carCol1.substring(1);
                                carCollection.getCar(indexNum).setColor1(newCol1);
                            }
                            if(carCol2.equals(""))
                                carCollection.getCar(indexNum).setColor2("");
                            else
                            {
                                String newCol2 = carCol2.substring(0,1).toUpperCase() + carCol2.substring(1);
                                carCollection.getCar(indexNum).setColor2(newCol2);
                            }
                            if(carCol3.equals(""))
                                carCollection.getCar(indexNum).setColor3("");
                            else
                            {
                                String newCol3 = carCol3.substring(0,1).toUpperCase() + carCol3.substring(1);
                                carCollection.getCar(indexNum).setColor3(newCol3);
                            }
                        }
                    }
                    System.out.println(carCollection.getCar(Integer.parseInt(index)).carToString());
                    newFlag = false;
                }
                else
                {
                    System.out.println("At least one color needed and try again: ");
                    carCol1 = searchCar.nextLine();
                    carCol2 = searchCar.nextLine();
                    carCol3 = searchCar.nextLine();
                    newFlag = true;
                }
            }
            else
            {
                System.out.println("Please input valid colors: ");
                carCol1 = searchCar.nextLine();
                carCol2 = searchCar.nextLine();
                carCol3 = searchCar.nextLine();
                newFlag = true;
            }
        }
    }
    
    /**
     * editPrice() method - edit car price.
     * 
     * @param  index.
     * @return   null.
     */
    private void editPrice(String index)
    {
        Validation isValidation = new Validation();
        System.out.println("Please edit price");
        boolean validPrice = true;
        Scanner searchCar = new Scanner(System.in);
        String inputPrice = searchCar.nextLine();
        while (validPrice)
        {
            if (isValidation.checkNum(inputPrice))
            {
                carCollection.getCar(Integer.parseInt(index)).setPrice(Integer.parseInt(inputPrice));
                System.out.println(carCollection.getCar(Integer.parseInt(index)).carToString());
                validPrice = false;
            }
            else
            {
                System.out.println("Please input valid price: ");
                inputPrice = searchCar.nextLine();
                validPrice = true;
            }
        }
    }
    
    /**
     * editColors() method - check input value, as menu is from 1-3.
     * 
     * @param  null.
     * @return   order.
     */
    private String editMenuOption()
    {
       Scanner input = new Scanner(System.in);
       boolean flag = true;
       String order = null;
       while (flag)
       {
           order = input.nextLine();
           if (order.length() == 1)
           {
               char userOption = order.charAt(0);
               if (userOption >= '1' && userOption <= '3'  )
                   flag = false;
               else
               {
                   System.out.println("Invalid number (please input 1 - 3)");
                   flag = true;
               }
           }
           else
           {
               System.out.println("Please input a valid number (ex. 1-3)");
               flag = true;
           }
       }
       return order;
    }
    
    /**
     * editCarInfo() method - edit car information (only can edit colors and price of a car).
     * 
     * @param  null.
     * @return   null.
     */
    private void editCarInfo()
    {
        displayCurrentCars();
        String index = checkIndex();
        System.out.println("Please choose to edit car colors or car price");
        System.out.println("1. edit car colors");
        System.out.println("2. edit car price");
        System.out.println("3. edit car colors and car price");
        boolean flag = true;
        while (flag)
        {
            switch (editMenuOption())
            {
                case "1": editColors(index);
                break;
                case "2": editPrice(index);
                break;
                case "3": editColors(index);
                          editPrice(index);
                break;
            }
            flag = false;
        }
    }
        
    /**
     * searchByReg() method - searching car information in the car collection by registration number.
     * 
     * @param  null.
     * @return   null. 
     */
    private void searchByReg()
    {
        System.out.println("Please enter a car registration number: ");
        Validation isValidation = new Validation();
        Scanner search = new Scanner(System.in);
        CarCollection findCar = new CarCollection();
        String find = search.nextLine();
        boolean flag = true;
        while (flag)
        {
            if ((isValidation.checkStr(find) || isValidation.checkNum(find)) && find.length() <= 6)
            {
                boolean match = true;
                while(match)
                {
                    for (int i = 0; i < carCollection.countCar(); i++)
                    {
                        if (carCollection.getCar(i).getCarReg().toLowerCase().equals(find.toLowerCase()))
                        {
                            findCar.addCar(carCollection.getCar(i));
                        }
                    }
                    if (findCar.countCar() == 0)
                    {
                        System.out.println("No such car with this Registration Number.");
                        System.out.print("Please choose another Registration Number: ");
                        find = search.nextLine();
                        match = true;
                    }
                    else
                    {
                        for (int a = 0; a < findCar.countCar(); a++)
                        {
                            System.out.println(a + 1 + "." + findCar.getCar(a).carToString());
                        }
                        match = false;
                    }
                }
                flag = false;
            }
            else
            {
                System.out.println("Please use a valid registration number");
                find = search.nextLine();
                flag = true;
            }
        }
    }
    
    /**
     * searchByMM() method - searching car information in the car collection by car make and car model.
     * 
     * @param  null.
     * @return   null. 
     */
    private void searchByMM()
    {
        Validation isValidation = new Validation();
        Scanner search = new Scanner(System.in);
        CarCollection findCar = new CarCollection();
        System.out.println("Please input a Car Make: ");
        String find = search.nextLine();
        boolean flag = true;
        while (flag)
        {
            if (isValidation.checkStr(find))
            {
                boolean match = true;
                while (match)
                {
                    for (int i = 0; i < carCollection.countCar(); i++)
                    {
                        if (carCollection.getCar(i).getCarMake().toLowerCase().equals(find.toLowerCase()))
                        {
                            findCar.addCar(carCollection.getCar(i));//change both input and existint name to be low case
                        }
                    }
                    if (findCar.countCar() == 0)
                    {
                        System.out.println("No such car with this Car Make.");
                        System.out.println("Please input a Car Make again: ");
                        find = search.nextLine();
                        match = true;
                    }
                    else
                        match = false;
                }
                Scanner searchMod = new Scanner(System.in);
                CarCollection findCar1 = new CarCollection();
                CarCollection findCar2 = new CarCollection();
                System.out.println("Please input a Car Model: ");
                String findMod = searchMod.nextLine();
                boolean flagM = true;
                while (flagM)
                {
                    if (isValidation.checkStr(findMod) || isValidation.checkNum(findMod))
                    {
                        boolean matchM = true;
                        while (matchM)
                        {
                            if (findMod.toLowerCase().equals("any"))
                            {
                                for (int n = 0; n < findCar.countCar(); n++)
                                {
                                    System.out.println(n + 1 + "." + findCar.getCar(n).carToString());
                                }
                                matchM = false;
                            }
                            else
                            {
                                for (int i = 0; i < findCar.countCar(); i++)
                                {
                                    if (findCar.getCar(i).getCarModel().toLowerCase().equals(findMod.toLowerCase()))
                                        findCar1.addCar(findCar.getCar(i));
                                }
                                if (findCar1.countCar() == 0)
                                {
                                    System.out.println("No such car with this Car Model.");
                                    System.out.println("Please input a Car Model again: ");
                                    findMod = search.nextLine();
                                    matchM = true;
                                }
                                else
                                {
                                    for (int a = 0; a < findCar1.countCar(); a++)
                                    {
                                        System.out.println(a + 1 + "." + findCar1.getCar(a).carToString());
                                    }
                                    matchM = false;
                                }
                            }
                        }
                        flagM = false;
                    }
                    else
                    {
                        System.out.println("Please input a valid Car Model: ");
                        findMod = searchMod.nextLine();
                        flagM = true;
                    }
                }
                flag = false;
            }
            else
            {
                System.out.println("Please input a valid Car Make: ");
                find = search.nextLine();
                flag = true;
            }
        }
    }
    
    /**
     * searchByAge() method - searching car information in the car collection by car made year.
     * 
     * @param  null.
     * @return   null. 
     */
    private void searchByAge()
    {
        Validation isValidation = new Validation();
        Scanner search = new Scanner(System.in);
        CarCollection findCar = new CarCollection();
        System.out.print("Please input a car age: ");
        String input = search.nextLine();
        int year = Calendar.getInstance().get(Calendar.YEAR);
        boolean flag = true;
        while (flag)
        {
            if (isValidation.checkNum(input) && Integer.parseInt(input) <= year)
            {
                for (int i = 0; i < carCollection.countCar(); i++)
                {
                    int age = year - Integer.parseInt(input);
                    int carYear = carCollection.getCar(i).getYearMade();
                    if (carYear >= age && carYear <= year)
                    {
                         findCar.addCar(carCollection.getCar(i));
                    }
                }
                if (findCar.countCar() == 0)
                {
                    System.out.println("No such car with this car age.");
                    System.out.print("Please try a new car age: ");
                    input = search.nextLine();
                }
                else
                    for (int a = 0; a < findCar.countCar(); a++)
                    {
                        System.out.println(a + 1 + "." + findCar.getCar(a).carToString());
                    }
                flag = false;
            }
            else
            {
                System.out.println("Please use a valid car age: ");
                input = search.nextLine();
                flag = true;
            }
        }
    }
    
    /**
     * checkMaxPrice() method - check maximum prices typed by users.
     * 
     * @param  minPrice.
     * @return   null. 
     */
    private void checkMaxPrice(String minPrice)
    {
        Validation isValidation = new Validation();
        Scanner searchPrice = new Scanner(System.in);
        CarCollection findCar1 = new CarCollection();
        String maxPrice = searchPrice.nextLine();
        boolean flagM = true;
        while (flagM)
        {
            if (isValidation.checkNum(maxPrice))
            {
                 boolean matchM = true;
                 while (matchM)
                 {
                     for (int i = 0; i < carCollection.countCar(); i++)
                     {
                         if (Integer.parseInt(minPrice) < Integer.parseInt(maxPrice))
                         {
                             if (carCollection.getCar(i).getPrice() <= Integer.parseInt(maxPrice) &&
                                 carCollection.getCar(i).getPrice() > Integer.parseInt(minPrice))
                                 findCar1.addCar(carCollection.getCar(i));
                         }
                         else
                         {
                            System.out.println("Minimum Price must be lower than Maximum Price.");
                            System.out.print("Please type Max Price again: ");
                            maxPrice = searchPrice.nextLine();
                            matchM = true;
                         }
                     }
                     if (findCar1.countCar() == 0)
                     {
                         System.out.println("No such car with this range");
                         System.out.println("Please type a Maximum Price again: ");
                         maxPrice = searchPrice.nextLine();
                         matchM = true;
                     }
                     else
                     {
                         for (int i = 0; i < findCar1.countCar(); i++)
                         {
                             System.out.println(i + 1 + "." + findCar1.getCar(i).carToString());
                         }
                         matchM = false;
                     }
                 }
                 flagM = false;
            }
            else
            {
                 System.out.print("Please input a valid maximum price: ");
                 maxPrice = searchPrice.nextLine();
                 flagM = true;
            }
        }
    }
    
    /**
     * searchByPrice() method - searching car information in the car collection by car price (a range).
     * 
     * @param  null.
     * @return   null. 
     */
    private void searchByPrice()
    {
        Validation isValidation = new Validation();
        Scanner search = new Scanner(System.in);
        System.out.print("Please input a Minimum Price: ");
        String minPrice = search.nextLine();
        boolean flag = true;
        while (flag)
        {
            if (isValidation.checkNum(minPrice))
            {
                boolean match = true;
                while (match)
                {
                    for (int i = 0; i < carCollection.countCar(); i++)
                    { 
                        if (carCollection.getCar(i).getPrice() < Integer.parseInt(minPrice))
                        {
                            System.out.println("No such car price is higher than your input.");
                            System.out.println("Please input a minimum price again: ");
                            minPrice = search.nextLine();
                            match = true;
                        }
                        else
                            match = false;
                    }
                }
                flag = false;
            }
            else
            {
                System.out.print("Please input a valid Minimum Price: ");
                minPrice = search.nextLine();
                flag = true;
            }
        }
        checkMaxPrice(minPrice);
    }
    
    /**
     * searchByColor() method - searching car information in the car collection by car colors.
     * Up to three colors for each car.
     * @param  null.
     * @return   null. 
     */
    private void searchByColor()
    {
        Validation isValidation = new Validation();
        Scanner search = new Scanner(System.in);
        CarCollection findCar = new CarCollection();
        System.out.println("Please input a car color: ");
        String find = search.nextLine();
        boolean flag = true;
        while (flag)
        {
            if (isValidation.checkStr(find))
            {
                boolean match = true;
                while (match)
                {
                    for (int i = 0; i < carCollection.countCar(); i++)
                    {
                        if (carCollection.getCar(i).getColor1().toLowerCase().equals(find.toLowerCase())
                            || carCollection.getCar(i).getColor2().toLowerCase().equals(find.toLowerCase())
                            || carCollection.getCar(i).getColor3().toLowerCase().equals(find.toLowerCase()))
                        {
                            findCar.addCar(carCollection.getCar(i));
                        }
                    }
                    if (findCar.countCar() == 0)
                    {
                        System.out.println("No such car with this Color.");
                        System.out.print("Please choose another color: ");
                        find = search.nextLine();
                        match = true;
                    }
                    else
                    {
                        for (int a = 0; a < findCar.countCar(); a++)
                        {
                            System.out.println(a + 1 + "." + findCar.getCar(a).carToString());
                        }
                        match = false;
                    }
                }
                flag = false;
            }
            else
            {
                System.out.println("Please input valid characters.");
                System.out.println("Please input again: ");
                find = search.nextLine();
                flag = true;
            }
        }
    }
    
    /**
     * displaySystemDate() method - display current date and time.
     * 
     * @param  null.
     * @return   null. 
     */
    private void displaySystemDate()
    {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        System.out.println(dateFormat.format(cal.getTime()));
        System.out.println("");
    }
    
    /**
     * displaySubMenu() method - display sub menu.
     * 
     * @param  null.
     * @return   null. 
     */
    private void displaySubMenu()
    {
        System.out.println("Car Searching Options:");
        System.out.println("=======================");
        System.out.println("(1) By Registration Number");
        System.out.println("(2) By Car Make and Car Model");
        System.out.println("(3) By Age");
        System.out.println("(4) By Price (range)");
        System.out.println("(5) By Color");
        System.out.println("(6) Back to Main Menu");
    }
    
    /**
     * mainMenuOption() method - main operation and option choosing of main menu.
     * 
     * @param  null.
     * @return   order1.  choice of users
     */
    private String mainMenuOption()
    {
        Scanner typing1 = new Scanner(System.in);
       boolean flag1 = true;
       String order1 = null;
       while (flag1)
       {
           order1 = typing1.nextLine();
           if (order1.length() == 1)
           {
               char userOption1 = order1.charAt(0);
               if (userOption1 >= '1' && userOption1 <= '6'  )
                   flag1 = false;
               else
               {
                   System.out.println("Invalid number (please input 1 - 6)");
                   flag1 = true;
               }
           }
           else
           {
               System.out.println("Please input valid number (ex. 1-6)");
               flag1 = true;
           }
       }
       return order1; 
    }
    
    /**
     * subMenuOption() method -  operation and option choosing of sub menu.
     * 
     * @param  null.
     * @return   order2.  choice of users
     */
    private String subMenuOption()
    {
       Scanner typing2 = new Scanner(System.in);
       boolean flag2 = true;
       String order2 = null;
       while (flag2)
       {
           order2 = typing2.nextLine();
           if (order2.length() == 1)
           {
               char userOption2 = order2.charAt(0);
               if (userOption2 >= '1' && userOption2 <= '6'  )
                   flag2 = false;
               else
               {
                   System.out.println("Invalid number (please input 1 - 6)");
                   flag2 = true;
               }
           }
           else
           {
               System.out.println("Please input a valid number (ex. 1-6)");
               flag2 = true;
           }
       }
       return order2;
    }
    
    /**
     * writeCar() method -  store current information of cars in car collection to a .txt file.
     * 
     * @param  null.
     * @return   null.
     */
    private void writeCar()
    {
        try
        {
            String fileName = "usedcars.txt";
            File file = new File(fileName);
            PrintWriter output = new PrintWriter(fileName);
            for (int i = 0; i < carCollection.countCar(); i++)
            {
                output.write(carCollection.getAllCars().get(i).carToString() + "\r\n");
            }
            output.close();
        }
        catch (IOException ex)
        {
            System.out.println("Error! Try again.");
        }
    }
    
    /**
     * subMenuOperation() method -  operation of option choosing by users of sub menu.
     * 
     * @param  null.
     * @return   null.
     */
    private void subMenuOperation()
    {
        boolean breakSubMenu = true;
        while (breakSubMenu)
        {
            displaySubMenu();
            switch(subMenuOption())
            {
                case "1": searchByReg();
                break;
                case "2": searchByMM();
                break;
                case "3": searchByAge();
                break;
                case "4": searchByPrice();
                break;
                case "5": searchByColor();
                break;
                case "6":
                breakSubMenu = false;
                break;
            }
        }
    }
    
    /**
     * runSystem() method -  main method of the class to operate all functions of the used car system.
     * 
     * @param  null.
     * @return   null.
     */
    public void runSystem()
    {
        boolean newFlag = true;
        readCarInfo();
        while (newFlag)
        {
            displayMenu();
            switch (mainMenuOption())
            {
               case "1": subMenuOperation();
               break;
               case "2": addCar();
               break;
               case "3": deleteCar();
               break;
               case "4": editCarInfo();
               break;
               case "5": displaySystemDate();
               break;
               case "6":
               writeCar();
               System.exit(0);
            }
        }
    }
}
